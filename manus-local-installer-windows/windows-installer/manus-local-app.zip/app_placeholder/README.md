# Manus-Local

A locally hosted AI assistant application that works exactly like Manus but uses open-source tools and locally hosted Ollama with the Qwen2.5:32b-instruct model.

## Features

- Complete local processing - no API calls or external dependencies
- Powerful LLM agentic framework with comprehensive tool integration
- Web search capabilities
- File operations
- Browser automation
- Shell command execution
- Code execution in multiple languages
- Data analysis and visualization
- Web-based user interface
- Cross-platform support (Windows and Linux)

## Requirements

- Python 3.8 or higher
- Node.js 14 or higher
- Ollama (with Qwen2.5:32b-instruct model)
- Modern web browser
- 16GB RAM minimum (32GB recommended)
- 10GB free disk space
